var searchData=
[
  ['setdoublepresstime_0',['setDoublePressTime',['../class_m_d___u_i_switch.html#ac29e353ed13dc39671c221201ed1d8c4',1,'MD_UISwitch']]],
  ['setlongpresstime_1',['setLongPressTime',['../class_m_d___u_i_switch.html#acddb4bac7da9b76b2ffb64b5fd301c2d',1,'MD_UISwitch']]],
  ['setpresstime_2',['setPressTime',['../class_m_d___u_i_switch.html#af547a652ad73aff32c8476f5423c56e6',1,'MD_UISwitch']]],
  ['setrepeattime_3',['setRepeatTime',['../class_m_d___u_i_switch.html#a758aeea794e3c2ea3b0270e7d71fc04d',1,'MD_UISwitch']]]
];
