var searchData=
[
  ['longpress_5fenable_0',['LONGPRESS_ENABLE',['../class_m_d___u_i_switch.html#ad053848d2409832412d46042accb76e8',1,'MD_UISwitch']]]
];
