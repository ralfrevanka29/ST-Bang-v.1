var searchData=
[
  ['repeat_5fenable_0',['REPEAT_ENABLE',['../class_m_d___u_i_switch.html#aeff0768820be6fd3d5b699735f7defff',1,'MD_UISwitch']]],
  ['repeat_5fresult_5fenable_1',['REPEAT_RESULT_ENABLE',['../class_m_d___u_i_switch.html#a8bb598e2f7533b6395ef4b01fc5e83a2',1,'MD_UISwitch']]]
];
